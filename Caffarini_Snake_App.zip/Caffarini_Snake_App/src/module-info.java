module SnakeFX {
  exports game;
  requires javafx.base;
  requires javafx.controls;
  requires transitive javafx.graphics;
  requires org.junit.jupiter.api;
  requires java.desktop;
  requires java.logging;

}